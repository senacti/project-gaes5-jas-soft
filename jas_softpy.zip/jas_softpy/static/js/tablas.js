$(document).ready( function () {
    $("#tablas").Datatable();
});