from django.contrib import admin


from .models import ShippingAddress

admin.site.register(ShippingAddress)
