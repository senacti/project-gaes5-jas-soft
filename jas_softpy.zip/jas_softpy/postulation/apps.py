from django.apps import AppConfig


class PostulationConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'postulation'
